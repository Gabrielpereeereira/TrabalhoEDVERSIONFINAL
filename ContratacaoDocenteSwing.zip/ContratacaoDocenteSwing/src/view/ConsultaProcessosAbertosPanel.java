package view;

import javax.swing.*;

public class ConsultaProcessosAbertosPanel extends JPanel {

    private JButton btnConsultar;

    private JTextArea txtResultado;

    public ConsultaProcessosAbertosPanel() {

        setLayout(null);

        JLabel lblTitulo =
                new JLabel("Processos Abertos");

        lblTitulo.setBounds(20,20,300,25);

        add(lblTitulo);

        btnConsultar =
                new JButton("Consultar");

        btnConsultar.setBounds(
                20,
                60,
                150,
                30);

        add(btnConsultar);

        txtResultado =
                new JTextArea();

        JScrollPane scroll =
                new JScrollPane(txtResultado);

        scroll.setBounds(
                20,
                120,
                800,
                400);

        add(scroll);
    }

    public JButton getBtnConsultar() {
        return btnConsultar;
    }

    public JTextArea getTxtResultado() {
        return txtResultado;
    }
}