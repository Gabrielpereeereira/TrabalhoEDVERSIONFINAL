package view;

import javax.swing.*;
import java.awt.*;
import controller.CursoController;

public class CursoPanel extends JPanel {

    private JTextField txtCodigo;
    private JTextField txtNome;
    private JTextField txtAreaConhecimento;
    private JTextArea txtResultado;

    public CursoPanel() {

        setLayout(null);

        JLabel lblTitulo = new JLabel("CRUD Curso");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 18));
        lblTitulo.setBounds(20, 10, 200, 30);
        add(lblTitulo);

        JLabel lblCodigo = new JLabel("Código:");
        lblCodigo.setBounds(20, 60, 120, 25);
        add(lblCodigo);

        txtCodigo = new JTextField();
        txtCodigo.setBounds(150, 60, 200, 25);
        add(txtCodigo);

        JLabel lblNome = new JLabel("Nome:");
        lblNome.setBounds(20, 100, 120, 25);
        add(lblNome);

        txtNome = new JTextField();
        txtNome.setBounds(150, 100, 200, 25);
        add(txtNome);

        JLabel lblArea = new JLabel("Área Conhecimento:");
        lblArea.setBounds(20, 140, 120, 25);
        add(lblArea);

        txtAreaConhecimento = new JTextField();
        txtAreaConhecimento.setBounds(150, 140, 200, 25);
        add(txtAreaConhecimento);

        JButton btnCadastrar = new JButton("Cadastrar");
        btnCadastrar.setBounds(20, 190, 120, 30);
        add(btnCadastrar);

        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(150, 190, 120, 30);
        add(btnBuscar);

        JButton btnAtualizar = new JButton("Atualizar");
        btnAtualizar.setBounds(280, 190, 120, 30);
        add(btnAtualizar);

        JButton btnRemover = new JButton("Remover");
        btnRemover.setBounds(410, 190, 120, 30);
        add(btnRemover);

        txtResultado = new JTextArea();
        txtResultado.setEditable(false);

        JScrollPane scroll = new JScrollPane(txtResultado);
        scroll.setBounds(20, 250, 700, 250);
        add(scroll);

        CursoController controller =
                new CursoController(
                        txtCodigo,
                        txtNome,
                        txtAreaConhecimento,
                        txtResultado);

        btnCadastrar.addActionListener(controller);
        btnBuscar.addActionListener(controller);
        btnAtualizar.addActionListener(controller);
        btnRemover.addActionListener(controller);
    }
}