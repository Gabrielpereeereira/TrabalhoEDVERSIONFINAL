package view;

import javax.swing.*;

public class ProfessorPanel extends JPanel {

    private JTextField txtCpf;
    private JTextField txtNome;
    private JTextField txtAreaPretensao;
    private JTextField txtPontuacao;

    private JTextArea txtResultado;

    private JButton btnCadastrar;
    private JButton btnBuscar;
    private JButton btnAtualizar;
    private JButton btnRemover;

    public ProfessorPanel() {

        setLayout(null);

        JLabel lblTitulo = new JLabel("CRUD Professor");
        lblTitulo.setBounds(20, 20, 200, 25);
        add(lblTitulo);

        JLabel lblCpf = new JLabel("CPF:");
        lblCpf.setBounds(20, 60, 120, 25);
        add(lblCpf);

        txtCpf = new JTextField();
        txtCpf.setBounds(150, 60, 200, 25);
        add(txtCpf);

        JLabel lblNome = new JLabel("Nome:");
        lblNome.setBounds(20, 100, 120, 25);
        add(lblNome);

        txtNome = new JTextField();
        txtNome.setBounds(150, 100, 200, 25);
        add(txtNome);

        JLabel lblArea = new JLabel("Área Pretensão:");
        lblArea.setBounds(20, 140, 120, 25);
        add(lblArea);

        txtAreaPretensao = new JTextField();
        txtAreaPretensao.setBounds(150, 140, 200, 25);
        add(txtAreaPretensao);

        JLabel lblPontuacao = new JLabel("Pontuação:");
        lblPontuacao.setBounds(20, 180, 120, 25);
        add(lblPontuacao);

        txtPontuacao = new JTextField();
        txtPontuacao.setBounds(150, 180, 200, 25);
        add(txtPontuacao);

        btnCadastrar = new JButton("Cadastrar");
        btnCadastrar.setBounds(20, 250, 120, 30);
        add(btnCadastrar);

        btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(150, 250, 120, 30);
        add(btnBuscar);

        btnAtualizar = new JButton("Atualizar");
        btnAtualizar.setBounds(280, 250, 120, 30);
        add(btnAtualizar);

        btnRemover = new JButton("Remover");
        btnRemover.setBounds(410, 250, 120, 30);
        add(btnRemover);

        txtResultado = new JTextArea();

        JScrollPane scroll = new JScrollPane(txtResultado);
        scroll.setBounds(20, 320, 700, 220);
        add(scroll);
    }

    public JTextField getTxtCpf() {
        return txtCpf;
    }

    public JTextField getTxtNome() {
        return txtNome;
    }

    public JTextField getTxtAreaPretensao() {
        return txtAreaPretensao;
    }

    public JTextField getTxtPontuacao() {
        return txtPontuacao;
    }

    public JTextArea getTxtResultado() {
        return txtResultado;
    }

    public JButton getBtnCadastrar() {
        return btnCadastrar;
    }

    public JButton getBtnBuscar() {
        return btnBuscar;
    }

    public JButton getBtnAtualizar() {
        return btnAtualizar;
    }

    public JButton getBtnRemover() {
        return btnRemover;
    }
}