package view;

import javax.swing.*;

public class InscricaoPanel extends JPanel {

    private JTextField txtCodigoProcesso;
    private JTextField txtCpfProfessor;
    private JTextField txtCodigoDisciplina;

    private JTextArea txtResultado;

    private JButton btnCadastrar;
    private JButton btnBuscar;
    private JButton btnAtualizar;
    private JButton btnRemover;

    public InscricaoPanel() {

        setLayout(null);

        JLabel lblTitulo = new JLabel("CRUD Inscrição");
        lblTitulo.setBounds(20,20,200,25);
        add(lblTitulo);

        JLabel lblProcesso = new JLabel("Código Processo:");
        lblProcesso.setBounds(20,60,120,25);
        add(lblProcesso);

        txtCodigoProcesso = new JTextField();
        txtCodigoProcesso.setBounds(150,60,200,25);
        add(txtCodigoProcesso);

        JLabel lblCpf = new JLabel("CPF Professor:");
        lblCpf.setBounds(20,100,120,25);
        add(lblCpf);

        txtCpfProfessor = new JTextField();
        txtCpfProfessor.setBounds(150,100,200,25);
        add(txtCpfProfessor);

        JLabel lblDisciplina = new JLabel("Código Disciplina:");
        lblDisciplina.setBounds(20,140,120,25);
        add(lblDisciplina);

        txtCodigoDisciplina = new JTextField();
        txtCodigoDisciplina.setBounds(150,140,200,25);
        add(txtCodigoDisciplina);

        btnCadastrar = new JButton("Cadastrar");
        btnCadastrar.setBounds(20,220,120,30);
        add(btnCadastrar);

        btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(150,220,120,30);
        add(btnBuscar);

        btnAtualizar = new JButton("Atualizar");
        btnAtualizar.setBounds(280,220,120,30);
        add(btnAtualizar);

        btnRemover = new JButton("Remover");
        btnRemover.setBounds(410,220,120,30);
        add(btnRemover);

        txtResultado = new JTextArea();

        JScrollPane scroll =
                new JScrollPane(txtResultado);

        scroll.setBounds(20,300,700,220);

        add(scroll);
    }

    public JTextField getTxtCodigoProcesso() {
        return txtCodigoProcesso;
    }

    public JTextField getTxtCpfProfessor() {
        return txtCpfProfessor;
    }

    public JTextField getTxtCodigoDisciplina() {
        return txtCodigoDisciplina;
    }

    public JTextArea getTxtResultado() {
        return txtResultado;
    }

    public JButton getBtnCadastrar() {
        return btnCadastrar;
    }

    public JButton getBtnBuscar() {
        return btnBuscar;
    }

    public JButton getBtnAtualizar() {
        return btnAtualizar;
    }

    public JButton getBtnRemover() {
        return btnRemover;
    }
}