package view;

import javax.swing.*;

public class DisciplinaPanel extends JPanel {

    private JTextField txtCodigo;
    private JTextField txtNome;
    private JTextField txtDiaSemana;
    private JTextField txtHorarioInicial;
    private JTextField txtQuantidadeHoras;
    private JTextField txtCodigoCurso;

    private JTextArea txtResultado;

    private JButton btnCadastrar;
    private JButton btnBuscar;
    private JButton btnAtualizar;
    private JButton btnRemover;

    public DisciplinaPanel() {

        setLayout(null);

        JLabel lblTitulo = new JLabel("CRUD Disciplina");
        lblTitulo.setBounds(20, 20, 200, 25);
        add(lblTitulo);

        JLabel lblCodigo = new JLabel("Código:");
        lblCodigo.setBounds(20, 60, 120, 25);
        add(lblCodigo);

        txtCodigo = new JTextField();
        txtCodigo.setBounds(150, 60, 200, 25);
        add(txtCodigo);

        JLabel lblNome = new JLabel("Nome:");
        lblNome.setBounds(20, 100, 120, 25);
        add(lblNome);

        txtNome = new JTextField();
        txtNome.setBounds(150, 100, 200, 25);
        add(txtNome);

        JLabel lblDiaSemana = new JLabel("Dia Semana:");
        lblDiaSemana.setBounds(20, 140, 120, 25);
        add(lblDiaSemana);

        txtDiaSemana = new JTextField();
        txtDiaSemana.setBounds(150, 140, 200, 25);
        add(txtDiaSemana);

        JLabel lblHorario = new JLabel("Horário Inicial:");
        lblHorario.setBounds(20, 180, 120, 25);
        add(lblHorario);

        txtHorarioInicial = new JTextField();
        txtHorarioInicial.setBounds(150, 180, 200, 25);
        add(txtHorarioInicial);

        JLabel lblHoras = new JLabel("Quantidade Horas:");
        lblHoras.setBounds(20, 220, 120, 25);
        add(lblHoras);

        txtQuantidadeHoras = new JTextField();
        txtQuantidadeHoras.setBounds(150, 220, 200, 25);
        add(txtQuantidadeHoras);

        JLabel lblCurso = new JLabel("Código Curso:");
        lblCurso.setBounds(20, 260, 120, 25);
        add(lblCurso);

        txtCodigoCurso = new JTextField();
        txtCodigoCurso.setBounds(150, 260, 200, 25);
        add(txtCodigoCurso);

        btnCadastrar = new JButton("Cadastrar");
        btnCadastrar.setBounds(20, 320, 120, 30);
        add(btnCadastrar);

        btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(150, 320, 120, 30);
        add(btnBuscar);

        btnAtualizar = new JButton("Atualizar");
        btnAtualizar.setBounds(280, 320, 120, 30);
        add(btnAtualizar);

        btnRemover = new JButton("Remover");
        btnRemover.setBounds(410, 320, 120, 30);
        add(btnRemover);

        txtResultado = new JTextArea();
        txtResultado.setEditable(false);

        JScrollPane scroll = new JScrollPane(txtResultado);
        scroll.setBounds(20, 380, 850, 180);
        add(scroll);
    }

    public JTextField getTxtCodigo() {
        return txtCodigo;
    }

    public JTextField getTxtNome() {
        return txtNome;
    }

    public JTextField getTxtDiaSemana() {
        return txtDiaSemana;
    }

    public JTextField getTxtHorarioInicial() {
        return txtHorarioInicial;
    }

    public JTextField getTxtQuantidadeHoras() {
        return txtQuantidadeHoras;
    }

    public JTextField getTxtCodigoCurso() {
        return txtCodigoCurso;
    }

    public JTextArea getTxtResultado() {
        return txtResultado;
    }

    public JButton getBtnCadastrar() {
        return btnCadastrar;
    }

    public JButton getBtnBuscar() {
        return btnBuscar;
    }

    public JButton getBtnAtualizar() {
        return btnAtualizar;
    }

    public JButton getBtnRemover() {
        return btnRemover;
    }
}