package view;

import javax.swing.JPanel;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

import controller.CursoController;

import java.awt.Font;

public class TelaCurso extends JPanel {

    private static final long serialVersionUID = 1L;

    private JTextField txtCodigo;
    private JTextField txtNome;
    private JTextField txtAreaConhecimento;
    private JTextArea txtResultado;

    private JButton btnCadastrar;
    private JButton btnBuscar;
    private JButton btnAtualizar;
    private JButton btnRemover;

    public TelaCurso() {

        setLayout(null);

        JLabel lblTitulo = new JLabel("CRUD Curso");
        lblTitulo.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setBounds(300, 20, 200, 30);
        add(lblTitulo);

        JLabel lblCodigo = new JLabel("Código:");
        lblCodigo.setBounds(50, 80, 100, 25);
        add(lblCodigo);

        txtCodigo = new JTextField();
        txtCodigo.setBounds(180, 80, 200, 25);
        add(txtCodigo);
        txtCodigo.setColumns(10);

        JLabel lblNome = new JLabel("Nome:");
        lblNome.setBounds(50, 120, 100, 25);
        add(lblNome);

        txtNome = new JTextField();
        txtNome.setBounds(180, 120, 300, 25);
        add(txtNome);
        txtNome.setColumns(10);

        JLabel lblAreaConhecimento = new JLabel("Área Conhecimento:");
        lblAreaConhecimento.setBounds(50, 160, 120, 25);
        add(lblAreaConhecimento);

        txtAreaConhecimento = new JTextField();
        txtAreaConhecimento.setBounds(180, 160, 300, 25);
        add(txtAreaConhecimento);
        txtAreaConhecimento.setColumns(10);

        btnCadastrar = new JButton("Cadastrar");
        btnCadastrar.setBounds(50, 220, 120, 30);
        add(btnCadastrar);

        btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(180, 220, 120, 30);
        add(btnBuscar);

        btnAtualizar = new JButton("Atualizar");
        btnAtualizar.setBounds(310, 220, 120, 30);
        add(btnAtualizar);

        btnRemover = new JButton("Remover");
        btnRemover.setBounds(440, 220, 120, 30);
        add(btnRemover);

        JLabel lblResultado = new JLabel("Resultado:");
        lblResultado.setBounds(50, 290, 100, 25);
        add(lblResultado);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(50, 320, 700, 200);
        add(scrollPane);

        txtResultado = new JTextArea();
        txtResultado.setEditable(false);
        scrollPane.setViewportView(txtResultado);
        
        //new CursoController(this);
    }

    // GETTERS

    public JTextField getTxtCodigo() {
        return txtCodigo;
    }

    public JTextField getTxtNome() {
        return txtNome;
    }

    public JTextField getTxtAreaConhecimento() {
        return txtAreaConhecimento;
    }	

    public JTextArea getTxtResultado() {
        return txtResultado;
    }

    public JButton getBtnCadastrar() {
        return btnCadastrar;
    }

    public JButton getBtnBuscar() {
        return btnBuscar;
    }

    public JButton getBtnAtualizar() {
        return btnAtualizar;
    }

    public JButton getBtnRemover() {
        return btnRemover;
    }
    
}