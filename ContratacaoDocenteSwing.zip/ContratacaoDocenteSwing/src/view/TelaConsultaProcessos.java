package view;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import java.awt.Font;

import model.Curso;
import model.Disciplina;

import estrutura.Fila;

import persistence.CursoRepository;
import persistence.DisciplinaRepository;
import persistence.InscricaoRepository;

import structure.HashTable;
import structure.Lista;

public class TelaConsultaProcessos extends JPanel {

    private static final long serialVersionUID = 1L;

    private JTextArea txtResultado;
    private JButton btnConsultar;

    private InscricaoRepository inscricaoRepository;
    private DisciplinaRepository disciplinaRepository;
    private CursoRepository cursoRepository;

    public TelaConsultaProcessos() {

        inscricaoRepository = new InscricaoRepository();
        disciplinaRepository = new DisciplinaRepository();
        cursoRepository = new CursoRepository();

        setLayout(null);

        JLabel lblTitulo = new JLabel("Consulta de Processos Abertos");
        lblTitulo.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setBounds(200, 20, 400, 30);
        add(lblTitulo);

        btnConsultar = new JButton("Consultar Processos Abertos");
        btnConsultar.setBounds(250, 80, 250, 35);
        add(btnConsultar);

        JLabel lblResultado = new JLabel("Resultado:");
        lblResultado.setBounds(50, 150, 100, 25);
        add(lblResultado);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(50, 180, 700, 350);
        add(scrollPane);

        txtResultado = new JTextArea();
        txtResultado.setEditable(false);

        scrollPane.setViewportView(txtResultado);

        btnConsultar.addActionListener(e -> {
            try {
                consultar();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(
                        null,
                        ex.getMessage(),
                        "Erro",
                        JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void consultar() throws Exception {

        HashTable hashTable =
                inscricaoRepository.getProcessosAbertosHashTable();

        if (hashTable.size() == 0) {

            txtResultado.setText(
                    "Nenhum processo aberto encontrado");

            return;
        }

        Lista codigosDisciplinas =
                hashTable.getKeys();

        if (codigosDisciplinas.size() == 0) {

            txtResultado.setText(
                    "Nenhum processo aberto encontrado");

            return;
        }

        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < codigosDisciplinas.size(); i++) {

            String codigoDisciplina =
                    (String) codigosDisciplinas.get(i);

            Fila filaDisciplina =
                    disciplinaRepository
                            .buscarPorCodigoComFila(
                                    codigoDisciplina);

            if (!filaDisciplina.isEmpty()) {

                Disciplina disciplina =
                        (Disciplina) filaDisciplina.remove();

                Fila filaCurso =
                        cursoRepository
                                .buscarPorCodigoComFila(
                                        disciplina.getCodigoCurso());

                sb.append("========================\n");

                sb.append("DISCIPLINA\n");

                sb.append("Código: ")
                  .append(disciplina.getCodigo())
                  .append("\n");

                sb.append("Nome: ")
                  .append(disciplina.getNome())
                  .append("\n");

                sb.append("Dia Semana: ")
                  .append(disciplina.getDiaSemana())
                  .append("\n");

                sb.append("Horário: ")
                  .append(disciplina.getHorarioInicial())
                  .append("\n");

                sb.append("Horas: ")
                  .append(disciplina.getQuantidadeHorasDiarias())
                  .append("\n");

                if (!filaCurso.isEmpty()) {

                    Curso curso =
                            (Curso) filaCurso.remove();

                    sb.append("\nCURSO\n");

                    sb.append("Código: ")
                      .append(curso.getCodigo())
                      .append("\n");

                    sb.append("Nome: ")
                      .append(curso.getNome())
                      .append("\n");

                    sb.append("Área: ")
                      .append(curso.getAreaConhecimento())
                      .append("\n");
                }

                sb.append("\n");
            }
        }

        txtResultado.setText(sb.toString());
    }

    public JTextArea getTxtResultado() {
        return txtResultado;
    }

    public JButton getBtnConsultar() {
        return btnConsultar;
    }
}