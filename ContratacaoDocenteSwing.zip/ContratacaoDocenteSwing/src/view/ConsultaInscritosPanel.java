package view;

import javax.swing.*;

public class ConsultaInscritosPanel extends JPanel {

    private JTextField txtCodigoDisciplina;

    private JButton btnConsultar;

    private JTextArea txtResultado;

    public ConsultaInscritosPanel() {

        setLayout(null);

        JLabel lblTitulo =
                new JLabel("Consulta de Inscritos");

        lblTitulo.setBounds(20,20,300,25);

        add(lblTitulo);

        JLabel lblCodigo =
                new JLabel("Código Disciplina:");

        lblCodigo.setBounds(20,70,150,25);

        add(lblCodigo);

        txtCodigoDisciplina =
                new JTextField();

        txtCodigoDisciplina.setBounds(
                170,
                70,
                200,
                25);

        add(txtCodigoDisciplina);

        btnConsultar =
                new JButton("Consultar");

        btnConsultar.setBounds(
                390,
                70,
                120,
                30);

        add(btnConsultar);

        txtResultado =
                new JTextArea();

        JScrollPane scroll =
                new JScrollPane(txtResultado);

        scroll.setBounds(
                20,
                130,
                800,
                400);

        add(scroll);
    }

    public JTextField getTxtCodigoDisciplina() {
        return txtCodigoDisciplina;
    }

    public JButton getBtnConsultar() {
        return btnConsultar;
    }

    public JTextArea getTxtResultado() {
        return txtResultado;
    }
}