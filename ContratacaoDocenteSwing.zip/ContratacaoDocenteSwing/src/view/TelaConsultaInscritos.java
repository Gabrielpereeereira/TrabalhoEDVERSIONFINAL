package view;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import java.awt.Font;

import estrutura.Fila;
import estrutura.Lista;
import model.Inscricao;
import model.Professor;
import persistence.InscricaoRepository;
import persistence.ProfessorRepository;
import util.QuickSort;

public class TelaConsultaInscritos extends JPanel {

    private static final long serialVersionUID = 1L;

    private JTextField txtCodigoDisciplina;
    private JTextArea txtResultado;
    private JButton btnConsultar;

    private InscricaoRepository inscricaoRepository;
    private ProfessorRepository professorRepository;

    public TelaConsultaInscritos() {

        inscricaoRepository = new InscricaoRepository();
        professorRepository = new ProfessorRepository();

        setLayout(null);

        JLabel lblTitulo = new JLabel("Consulta de Inscritos por Disciplina");
        lblTitulo.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setBounds(180, 20, 450, 30);
        add(lblTitulo);

        JLabel lblCodigoDisciplina = new JLabel("Código Disciplina:");
        lblCodigoDisciplina.setBounds(50, 90, 130, 25);
        add(lblCodigoDisciplina);

        txtCodigoDisciplina = new JTextField();
        txtCodigoDisciplina.setBounds(190, 90, 200, 25);
        add(txtCodigoDisciplina);

        btnConsultar = new JButton("Consultar");
        btnConsultar.setBounds(420, 90, 120, 25);
        add(btnConsultar);

        JLabel lblResultado = new JLabel("Resultado (ordenado por pontuação):");
        lblResultado.setBounds(50, 150, 300, 25);
        add(lblResultado);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(50, 180, 700, 350);
        add(scrollPane);

        txtResultado = new JTextArea();
        txtResultado.setEditable(false);

        scrollPane.setViewportView(txtResultado);

        btnConsultar.addActionListener(e -> consultar());
    }

    private void consultar() {

        try {

            String codigoDisciplina =
                    txtCodigoDisciplina.getText().trim();

            if (codigoDisciplina.isEmpty()) {
                JOptionPane.showMessageDialog(
                        null,
                        "Informe o código da disciplina",
                        "Erro",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            Lista inscricoes =
                    inscricaoRepository.buscarInscricoesPorDisciplina(
                            codigoDisciplina);

            if (inscricoes.size() == 0) {

                txtResultado.setText(
                        "Nenhuma inscrição encontrada para esta disciplina");

                return;
            }

            Lista professores = new Lista();

            for (int i = 0; i < inscricoes.size(); i++) {

                Inscricao insc =
                        (Inscricao) inscricoes.get(i);

                Fila fila =
                        professorRepository.buscarPorCpfComFila(
                                insc.getCpfProfessor());

                if (!fila.isEmpty()) {

                    Professor prof =
                            (Professor) fila.remove();

                    professores.addLast(prof);
                }
            }

            QuickSort quickSort = new QuickSort();

            quickSort.sortByPontuacao(professores);

            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < professores.size(); i++) {

                Professor prof =
                        (Professor) professores.get(i);

                sb.append("------------------------\n");

                sb.append("CPF: ")
                  .append(prof.getCpf())
                  .append("\n");

                sb.append("Nome: ")
                  .append(prof.getNome())
                  .append("\n");

                sb.append("Área Pretensão: ")
                  .append(prof.getAreaPretensao())
                  .append("\n");

                sb.append("Pontuação: ")
                  .append(prof.getPontuacao())
                  .append("\n\n");
            }

            txtResultado.setText(sb.toString());

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    null,
                    e.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}