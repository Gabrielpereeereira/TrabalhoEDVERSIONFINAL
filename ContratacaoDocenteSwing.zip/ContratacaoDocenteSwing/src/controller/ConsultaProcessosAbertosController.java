package controller;

import javax.swing.JOptionPane;

import persistence.InscricaoRepository;
import structure.HashTable;
import structure.Lista;
import view.ConsultaProcessosAbertosPanel;

public class ConsultaProcessosAbertosController {

    private ConsultaProcessosAbertosPanel view;

    private InscricaoRepository repository;

    public ConsultaProcessosAbertosController(
            ConsultaProcessosAbertosPanel view) {

        this.view = view;

        repository = new InscricaoRepository();

        configurarEventos();
    }

    private void configurarEventos() {

        view.getBtnConsultar()
                .addActionListener(e -> consultar());
    }

    private void consultar() {

        try {

            HashTable tabela =
                    repository.getProcessosAbertosHashTable();

            Lista chaves =
                    tabela.getKeys();

            StringBuilder sb =
                    new StringBuilder();

            for(int i=0;i<chaves.size();i++) {

                sb.append(
                        chaves.get(i))
                        .append("\n");
            }

            view.getTxtResultado()
                    .setText(sb.toString());

        } catch(Exception ex) {

            JOptionPane.showMessageDialog(
                    null,
                    ex.getMessage());
        }
    }
}