package controller;

import javax.swing.JOptionPane;

import estrutura.Fila;
import estrutura.Lista;
import model.Inscricao;
import persistence.InscricaoRepository;
import persistence.ProfessorRepository;
import view.InscricaoPanel;

public class InscricaoController {

    private InscricaoPanel view;

    private InscricaoRepository repository;
    private ProfessorRepository professorRepository;

    public InscricaoController(InscricaoPanel view) {

        this.view = view;

        repository = new InscricaoRepository();
        professorRepository = new ProfessorRepository();

        configurarEventos();
    }

    private void configurarEventos() {

        view.getBtnCadastrar().addActionListener(e -> cadastrar());
        view.getBtnBuscar().addActionListener(e -> buscar());
        view.getBtnAtualizar().addActionListener(e -> atualizar());
        view.getBtnRemover().addActionListener(e -> remover());
    }

    private void cadastrar() {

        try {

            String processo =
                    view.getTxtCodigoProcesso().getText().trim();

            String cpf =
                    view.getTxtCpfProfessor().getText().trim();

            String disciplina =
                    view.getTxtCodigoDisciplina().getText().trim();

            if(processo.isEmpty() ||
               cpf.isEmpty() ||
               disciplina.isEmpty()) {

                JOptionPane.showMessageDialog(
                        null,
                        "Todos os campos devem ser preenchidos");

                return;
            }

            if(!professorRepository.professorExists(cpf)) {

                JOptionPane.showMessageDialog(
                        null,
                        "Professor não cadastrado");

                return;
            }

            Inscricao inscricao =
                    new Inscricao(processo, cpf, disciplina);

            repository.save(inscricao.toString());

            view.getTxtResultado()
                    .setText("Inscrição cadastrada com sucesso!");

            limparCampos();

        } catch(Exception ex) {

            JOptionPane.showMessageDialog(
                    null,
                    ex.getMessage());
        }
    }

    private void buscar() {

        try {

            Fila fila =
                    repository.buscarPorCodigoProcessoComFila(
                            view.getTxtCodigoProcesso()
                                    .getText()
                                    .trim());

            if(fila.isEmpty()) {

                view.getTxtResultado()
                        .setText("Inscrição não encontrada");

                return;
            }

            Inscricao i =
                    (Inscricao) fila.remove();

            view.getTxtResultado().setText(
                    "Código Processo: " + i.getCodigoProcesso() +
                    "\nCPF Professor: " + i.getCpfProfessor() +
                    "\nCódigo Disciplina: " + i.getCodigoDisciplina());

        } catch(Exception ex) {

            JOptionPane.showMessageDialog(
                    null,
                    ex.getMessage());
        }
    }

    private void atualizar() {

        try {

            Lista lista =
                    repository.buscarTodosComLista();

            boolean encontrou = false;

            for(int i=0;i<lista.size();i++) {

                Inscricao ins =
                        (Inscricao) lista.get(i);

                if(ins.getCodigoProcesso().equals(
                        view.getTxtCodigoProcesso()
                                .getText()
                                .trim())) {

                    ins.setCpfProfessor(
                            view.getTxtCpfProfessor().getText());

                    ins.setCodigoDisciplina(
                            view.getTxtCodigoDisciplina().getText());

                    encontrou = true;
                    break;
                }
            }

            if(encontrou) {

                repository.saveAll(lista);

                view.getTxtResultado()
                        .setText("Inscrição atualizada!");

            } else {

                view.getTxtResultado()
                        .setText("Inscrição não encontrada");
            }

        } catch(Exception ex) {

            JOptionPane.showMessageDialog(
                    null,
                    ex.getMessage());
        }
    }

    private void remover() {

        try {

            Lista lista =
                    repository.buscarTodosComLista();

            boolean encontrou = false;

            for(int i=0;i<lista.size();i++) {

                Inscricao ins =
                        (Inscricao) lista.get(i);

                if(ins.getCodigoProcesso().equals(
                        view.getTxtCodigoProcesso()
                                .getText()
                                .trim())) {

                    lista.remove(i);

                    encontrou = true;

                    break;
                }
            }

            if(encontrou) {

                repository.saveAll(lista);

                view.getTxtResultado()
                        .setText("Inscrição removida!");

            } else {

                view.getTxtResultado()
                        .setText("Inscrição não encontrada");
            }

        } catch(Exception ex) {

            JOptionPane.showMessageDialog(
                    null,
                    ex.getMessage());
        }
    }

    private void limparCampos() {

        view.getTxtCodigoProcesso().setText("");
        view.getTxtCpfProfessor().setText("");
        view.getTxtCodigoDisciplina().setText("");
    }
}