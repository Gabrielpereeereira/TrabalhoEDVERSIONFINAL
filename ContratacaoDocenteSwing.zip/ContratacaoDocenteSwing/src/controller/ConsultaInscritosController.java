package controller;

import javax.swing.JOptionPane;

import estrutura.Lista;
import model.Inscricao;
import model.Professor;
import persistence.InscricaoRepository;
import persistence.ProfessorRepository;
import util.QuickSort;
import view.ConsultaInscritosPanel;

public class ConsultaInscritosController {

    private ConsultaInscritosPanel view;

    private InscricaoRepository inscricaoRepository;
    private ProfessorRepository professorRepository;

    public ConsultaInscritosController(
            ConsultaInscritosPanel view) {

        this.view = view;

        inscricaoRepository =
                new InscricaoRepository();

        professorRepository =
                new ProfessorRepository();

        configurarEventos();
    }

    private void configurarEventos() {

        view.getBtnConsultar()
                .addActionListener(e -> consultar());
    }

    private void consultar() {

        try {

            String codigoDisciplina =
                    view.getTxtCodigoDisciplina()
                            .getText()
                            .trim();

            Lista inscricoes =
                    inscricaoRepository
                            .buscarInscricoesPorDisciplina(
                                    codigoDisciplina);

            Lista professores =
                    new Lista();

            Lista todosProfessores =
                    professorRepository
                            .buscarTodosComLista();

            for(int i=0;i<inscricoes.size();i++) {

                Inscricao ins =
                        (Inscricao) inscricoes.get(i);

                for(int j=0;j<todosProfessores.size();j++) {

                    Professor prof =
                            (Professor)
                                    todosProfessores.get(j);

                    if(prof.getCpf().equals(
                            ins.getCpfProfessor())) {

                        professores.addLast(prof);
                    }
                }
            }

            QuickSort quickSort =
                    new QuickSort();

            quickSort.sortByPontuacao(professores);

            StringBuilder sb =
                    new StringBuilder();

            for(int i=0;i<professores.size();i++) {

                Professor p =
                        (Professor) professores.get(i);

                sb.append("CPF: ")
                        .append(p.getCpf())
                        .append(" | Nome: ")
                        .append(p.getNome())
                        .append(" | Pontuação: ")
                        .append(p.getPontuacao())
                        .append("\n");
            }

            view.getTxtResultado()
                    .setText(sb.toString());

        } catch(Exception ex) {

            JOptionPane.showMessageDialog(
                    null,
                    ex.getMessage());
        }
    }
}