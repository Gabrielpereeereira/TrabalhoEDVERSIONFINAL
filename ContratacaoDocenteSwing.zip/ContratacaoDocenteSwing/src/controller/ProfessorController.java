package controller;

import javax.swing.JOptionPane;

import estrutura.Fila;
import estrutura.Lista;
import model.Professor;
import persistence.ProfessorRepository;
import view.ProfessorPanel;

public class ProfessorController {

    private ProfessorPanel view;
    private ProfessorRepository repository;

    public ProfessorController(ProfessorPanel view) {
        this.view = view;
        this.repository = new ProfessorRepository();

        configurarEventos();
    }

    private void configurarEventos() {

        view.getBtnCadastrar().addActionListener(e -> cadastrar());
        view.getBtnBuscar().addActionListener(e -> buscar());
        view.getBtnAtualizar().addActionListener(e -> atualizar());
        view.getBtnRemover().addActionListener(e -> remover());
    }

    private void cadastrar() {

        try {

            String cpf = view.getTxtCpf().getText().trim();
            String nome = view.getTxtNome().getText().trim();
            String area = view.getTxtAreaPretensao().getText().trim();
            String pontuacao = view.getTxtPontuacao().getText().trim();

            if (cpf.isEmpty() ||
                    nome.isEmpty() ||
                    area.isEmpty() ||
                    pontuacao.isEmpty()) {

                JOptionPane.showMessageDialog(
                        null,
                        "Todos os campos devem ser preenchidos");
                return;
            }

            Professor professor =
                    new Professor(cpf, nome, area, pontuacao);

            repository.save(professor.toString());

            view.getTxtResultado()
                    .setText("Professor cadastrado com sucesso!");

            limparCampos();

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    private void buscar() {

        try {

        	String cpf = view.getTxtCpf().getText().trim();

        	if(cpf.isEmpty()) {
        	    JOptionPane.showMessageDialog(
        	            null,
        	            "Informe o CPF do professor");
        	    return;
        	}

        	Fila fila = repository.buscarPorCpfComFila(cpf);

            if (fila.isEmpty()) {

                view.getTxtResultado()
                        .setText("Professor não encontrado");

            } else {

                Professor professor =
                        (Professor) fila.remove();

                String texto =
                        "CPF: " + professor.getCpf() + "\n" +
                        "Nome: " + professor.getNome() + "\n" +
                        "Área Pretensão: " + professor.getAreaPretensao() + "\n" +
                        "Pontuação: " + professor.getPontuacao();

                view.getTxtResultado().setText(texto);
            }

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    private void atualizar() {

        try {
        	
        	if(view.getTxtCpf().getText().trim().isEmpty() ||
        			   view.getTxtNome().getText().trim().isEmpty() ||
        			   view.getTxtAreaPretensao().getText().trim().isEmpty() ||
        			   view.getTxtPontuacao().getText().trim().isEmpty()) {

        			    JOptionPane.showMessageDialog(
        			            null,
        			            "Todos os campos devem ser preenchidos");
        			    return;
        			}

            Lista lista = repository.buscarTodosComLista();

            boolean encontrado = false;

            for (int i = 0; i < lista.size(); i++) {

                Professor p = (Professor) lista.get(i);

                if (p.getCpf().equals(
                        view.getTxtCpf().getText().trim())) {

                    p.setNome(view.getTxtNome().getText());
                    p.setAreaPretensao(view.getTxtAreaPretensao().getText());
                    p.setPontuacao(view.getTxtPontuacao().getText());

                    encontrado = true;
                    break;
                }
            }

            if (encontrado) {

                repository.saveAll(lista);

                view.getTxtResultado()
                        .setText("Professor atualizado com sucesso!");
                limparCampos();

            } else {

                view.getTxtResultado()
                        .setText("Professor não encontrado");
            }

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    private void remover() {

        try {

            String cpf = view.getTxtCpf().getText().trim();

            Lista lista = repository.buscarTodosComLista();

            boolean encontrado = false;

            for (int i = 0; i < lista.size(); i++) {

                Professor p = (Professor) lista.get(i);

                if (p.getCpf().equals(cpf)) {

                    lista.remove(i);
                    encontrado = true;
                    break;
                }
            }

            if (encontrado) {

                repository.saveAll(lista);

                view.getTxtResultado()
                        .setText("Professor removido com sucesso!");
                limparCampos();

            } else {

                view.getTxtResultado()
                        .setText("Professor não encontrado");
            }

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    private void limparCampos() {

        view.getTxtCpf().setText("");
        view.getTxtNome().setText("");
        view.getTxtAreaPretensao().setText("");
        view.getTxtPontuacao().setText("");
    }
}