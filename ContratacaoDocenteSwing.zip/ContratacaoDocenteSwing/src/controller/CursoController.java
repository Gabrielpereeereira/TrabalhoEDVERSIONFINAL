package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import estrutura.Fila;
import estrutura.Lista;
import model.Curso;
import persistence.CursoRepository;

public class CursoController implements ActionListener {

    private JTextField txtCodigo;
    private JTextField txtNome;
    private JTextField txtAreaConhecimento;
    private JTextArea txtAreaResultado;

    private CursoRepository repository;

    public CursoController(
            JTextField txtCodigo,
            JTextField txtNome,
            JTextField txtAreaConhecimento,
            JTextArea txtAreaResultado) {

        this.txtCodigo = txtCodigo;
        this.txtNome = txtNome;
        this.txtAreaConhecimento = txtAreaConhecimento;
        this.txtAreaResultado = txtAreaResultado;

        repository = new CursoRepository();
    }

    @Override
    public void actionPerformed(ActionEvent event) {

        JButton source = (JButton) event.getSource();
        String buttonText = source.getText();

        try {

            if (buttonText.equals("Cadastrar")) {
                cadastrar();
            }

            else if (buttonText.equals("Buscar")) {
                buscar();
            }

            else if (buttonText.equals("Atualizar")) {
                atualizar();
            }

            else if (buttonText.equals("Remover")) {
                remover();
            }

        } catch (Exception e) {
            showError("Erro: " + e.getMessage());
        }
    }

    private void cadastrar() throws Exception {

        String codigo = txtCodigo.getText().trim();
        String nome = txtNome.getText().trim();
        String area = txtAreaConhecimento.getText().trim();

        if (codigo.isEmpty() || nome.isEmpty() || area.isEmpty()) {
            showError("Todos os campos devem ser preenchidos");
            return;
        }

        Curso curso = new Curso(codigo, nome, area);

        repository.save(curso.toString());

        txtAreaResultado.setText("Curso cadastrado com sucesso!");

        limparCampos();
    }

    private void buscar() throws Exception {

        String codigo = txtCodigo.getText().trim();

        if (codigo.isEmpty()) {
            showError("Informe o código do curso");
            return;
        }

        Fila fila = repository.buscarPorCodigoComFila(codigo);

        if (fila.isEmpty()) {

            txtAreaResultado.setText("Curso não encontrado");

        } else {

            Curso curso = (Curso) fila.remove();

            StringBuilder sb = new StringBuilder();

            sb.append("Código: ")
              .append(curso.getCodigo())
              .append("\n");

            sb.append("Nome: ")
              .append(curso.getNome())
              .append("\n");

            sb.append("Área de Conhecimento: ")
              .append(curso.getAreaConhecimento());

            txtAreaResultado.setText(sb.toString());
        }

        limparCampos();
    }

    private void atualizar() throws Exception {

        String codigo = txtCodigo.getText().trim();
        String nome = txtNome.getText().trim();
        String area = txtAreaConhecimento.getText().trim();

        if (codigo.isEmpty() || nome.isEmpty() || area.isEmpty()) {
            showError("Todos os campos devem ser preenchidos");
            return;
        }

        Lista lista = repository.buscarTodosComLista();

        boolean encontrado = false;

        for (int i = 0; i < lista.size(); i++) {

            Curso curso = (Curso) lista.get(i);

            if (curso.getCodigo().equals(codigo)) {

                curso.setNome(nome);
                curso.setAreaConhecimento(area);

                encontrado = true;
                break;
            }
        }

        if (encontrado) {

            repository.saveAll(lista);

            txtAreaResultado.setText(
                    "Curso atualizado com sucesso!");

        } else {

            txtAreaResultado.setText(
                    "Curso não encontrado");
        }

        limparCampos();
    }

    private void remover() throws Exception {

        String codigo = txtCodigo.getText().trim();

        if (codigo.isEmpty()) {
            showError("Informe o código do curso");
            return;
        }

        Lista lista = repository.buscarTodosComLista();

        boolean encontrado = false;

        for (int i = 0; i < lista.size(); i++) {

            Curso curso = (Curso) lista.get(i);

            if (curso.getCodigo().equals(codigo)) {

                lista.remove(i);

                encontrado = true;
                break;
            }
        }

        if (encontrado) {

            repository.saveAll(lista);

            txtAreaResultado.setText(
                    "Curso removido com sucesso!");

        } else {

            txtAreaResultado.setText(
                    "Curso não encontrado");
        }

        limparCampos();
    }

    private void limparCampos() {

        txtCodigo.setText("");
        txtNome.setText("");
        txtAreaConhecimento.setText("");
    }

    private void showError(String mensagem) {

        JOptionPane.showMessageDialog(
                null,
                mensagem,
                "Erro",
                JOptionPane.ERROR_MESSAGE);
    }
}