package controller;

import javax.swing.JOptionPane;

import estrutura.Fila;
import estrutura.Lista;
import model.Disciplina;
import persistence.DisciplinaRepository;
import view.DisciplinaPanel;

public class DisciplinaController {

    private DisciplinaPanel view;
    private DisciplinaRepository repository;

    public DisciplinaController(DisciplinaPanel view) {

        this.view = view;
        this.repository = new DisciplinaRepository();

        configurarEventos();
    }

    private void configurarEventos() {

        view.getBtnCadastrar().addActionListener(e -> cadastrar());
        view.getBtnBuscar().addActionListener(e -> buscar());
        view.getBtnAtualizar().addActionListener(e -> atualizar());
        view.getBtnRemover().addActionListener(e -> remover());
    }

    private void cadastrar() {

        try {

            String codigo =
                    view.getTxtCodigo().getText().trim();

            String nome =
                    view.getTxtNome().getText().trim();

            String diaSemana =
                    view.getTxtDiaSemana().getText().trim();

            String horario =
                    view.getTxtHorarioInicial().getText().trim();

            String horas =
                    view.getTxtQuantidadeHoras().getText().trim();

            String codigoCurso =
                    view.getTxtCodigoCurso().getText().trim();

            if (codigo.isEmpty() ||
                nome.isEmpty() ||
                diaSemana.isEmpty() ||
                horario.isEmpty() ||
                horas.isEmpty() ||
                codigoCurso.isEmpty()) {

                JOptionPane.showMessageDialog(
                        null,
                        "Todos os campos devem ser preenchidos");

                return;
            }

            Disciplina disciplina =
                    new Disciplina(
                            codigo,
                            nome,
                            diaSemana,
                            horario,
                            horas,
                            codigoCurso);

            repository.save(disciplina.toString());

            view.getTxtResultado()
                    .setText("Disciplina cadastrada com sucesso!");

            limparCampos();

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    null,
                    ex.getMessage());
        }
    }

    private void buscar() {

        try {

            String codigo =
                    view.getTxtCodigo().getText().trim();

            Fila fila =
                    repository.buscarPorCodigoComFila(codigo);

            if (fila.isEmpty()) {

                view.getTxtResultado()
                        .setText("Disciplina não encontrada");

                return;
            }

            Disciplina disciplina =
                    (Disciplina) fila.remove();

            String texto =
                    "Código: " + disciplina.getCodigo() + "\n" +
                    "Nome: " + disciplina.getNome() + "\n" +
                    "Dia Semana: " + disciplina.getDiaSemana() + "\n" +
                    "Horário Inicial: " + disciplina.getHorarioInicial() + "\n" +
                    "Qtd Horas: " + disciplina.getQuantidadeHorasDiarias() + "\n" +
                    "Código Curso: " + disciplina.getCodigoCurso();

            view.getTxtResultado().setText(texto);

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    null,
                    ex.getMessage());
        }
    }

    private void atualizar() {

        try {

            Lista lista =
                    repository.buscarTodosComLista();

            boolean encontrado = false;

            for (int i = 0; i < lista.size(); i++) {

                Disciplina d =
                        (Disciplina) lista.get(i);

                if (d.getCodigo().equals(
                        view.getTxtCodigo()
                                .getText()
                                .trim())) {

                    d.setNome(
                            view.getTxtNome().getText());

                    d.setDiaSemana(
                            view.getTxtDiaSemana().getText());

                    d.setHorarioInicial(
                            view.getTxtHorarioInicial().getText());

                    d.setQuantidadeHorasDiarias(
                            view.getTxtQuantidadeHoras().getText());

                    d.setCodigoCurso(
                            view.getTxtCodigoCurso().getText());

                    encontrado = true;
                    break;
                }
            }

            if (encontrado) {

                repository.saveAll(lista);

                view.getTxtResultado()
                        .setText("Disciplina atualizada com sucesso!");

            } else {

                view.getTxtResultado()
                        .setText("Disciplina não encontrada");
            }

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    null,
                    ex.getMessage());
        }
    }

    private void remover() {

        try {

            String codigo =
                    view.getTxtCodigo().getText().trim();

            Lista lista =
                    repository.buscarTodosComLista();

            boolean encontrado = false;

            for (int i = 0; i < lista.size(); i++) {

                Disciplina d =
                        (Disciplina) lista.get(i);

                if (d.getCodigo().equals(codigo)) {

                    lista.remove(i);

                    encontrado = true;

                    break;
                }
            }

            if (encontrado) {

                repository.saveAll(lista);

                view.getTxtResultado()
                        .setText("Disciplina removida com sucesso!");

            } else {

                view.getTxtResultado()
                        .setText("Disciplina não encontrada");
            }

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    null,
                    ex.getMessage());
        }
    }

    private void limparCampos() {

        view.getTxtCodigo().setText("");
        view.getTxtNome().setText("");
        view.getTxtDiaSemana().setText("");
        view.getTxtHorarioInicial().setText("");
        view.getTxtQuantidadeHoras().setText("");
        view.getTxtCodigoCurso().setText("");
    }
}