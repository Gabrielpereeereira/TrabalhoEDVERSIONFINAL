package application;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.border.EmptyBorder;

import controller.ConsultaInscritosController;
import controller.ConsultaProcessosAbertosController;
import controller.DisciplinaController;
import controller.InscricaoController;
import controller.ProfessorController;
import view.ConsultaInscritosPanel;
import view.ConsultaProcessosAbertosPanel;
import view.CursoPanel;
import view.DisciplinaPanel;
import view.InscricaoPanel;
import view.ProfessorPanel;

public class MainFrame extends JFrame {

    private static final long serialVersionUID = 1L;

    private JPanel contentPane;
    private JTabbedPane tabbedPane;

    public static void main(String[] args) {

        EventQueue.invokeLater(() -> {

            try {

                MainFrame frame = new MainFrame();

                frame.setVisible(true);

            } catch (Exception e) {

                e.printStackTrace();
            }
        });
    }

    public MainFrame() {

        setTitle("Sistema de Contratação Docente");

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setSize(1000, 700);

        setLocationRelativeTo(null);

        contentPane = new JPanel();

        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);

        contentPane.setLayout(null);

        tabbedPane = new JTabbedPane();

        tabbedPane.setBounds(10, 10, 960, 620);

        contentPane.add(tabbedPane);

        tabbedPane.addTab("Cursos", new CursoPanel());

        DisciplinaPanel disciplinaPanel =
                new DisciplinaPanel();

        new DisciplinaController(disciplinaPanel);

        tabbedPane.addTab(
                "Disciplinas",
                disciplinaPanel);

        tabbedPane.addTab(
                "Disciplinas",
                disciplinaPanel);

        ProfessorPanel professorPanel =
                new ProfessorPanel();

        new ProfessorController(professorPanel);

        tabbedPane.addTab(
                "Professores",
                professorPanel);

        InscricaoPanel inscricaoPanel =
                new InscricaoPanel();

        new InscricaoController(inscricaoPanel);

        tabbedPane.addTab(
                "Inscrições",
                inscricaoPanel);

        ConsultaInscritosPanel consultaInscritos =
                new ConsultaInscritosPanel();

        new ConsultaInscritosController(
                consultaInscritos);

        tabbedPane.addTab(
                "Consulta Inscritos",
                consultaInscritos);

        ConsultaProcessosAbertosPanel consultaProcessos =
                new ConsultaProcessosAbertosPanel();

        new ConsultaProcessosAbertosController(
                consultaProcessos);

        tabbedPane.addTab(
                "Processos Abertos",
                consultaProcessos);
    }
}